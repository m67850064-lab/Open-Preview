import { useState, useRef, useEffect } from "react";
import type { Conversation } from "../types";

interface SidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  isOpen: boolean;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  onDeleteChat: (id: string) => void;
  onRenameChat: (id: string, newTitle: string) => void;
  onToggle: () => void;
}

export function Sidebar({
  conversations,
  activeId,
  isOpen,
  onNewChat,
  onSelectChat,
  onDeleteChat,
  onRenameChat,
  onToggle,
}: SidebarProps) {
  return (
    <>
      {/* --- Mobile (< md): overlay drawer --- */}
      {isOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={onToggle}
        />
      )}
      <aside
        className={`
          bg-surface border-r border-surface-light flex flex-col overflow-hidden
          pl-safe pt-safe
          transition-all duration-200
          fixed inset-y-0 left-0 z-40
          md:relative md:z-auto
          ${isOpen ? "w-[280px] translate-x-0 opacity-100" : "w-[280px] -translate-x-full opacity-0"}
          md:translate-x-0 md:opacity-100
          ${isOpen ? "md:w-[260px] md:min-w-[260px]" : "md:w-0 md:min-w-0"}
        `}
      >
        <div className="flex items-center gap-2.5 p-4">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-brand-500 to-brand-400">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" />
              <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="2" strokeLinejoin="round" opacity="0.7" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="font-heading text-base font-bold leading-tight">Vertex AI</span>
            <span className="text-[11px] leading-tight text-neutral-400">Assistant</span>
          </div>
        </div>

        <div className="px-4 pb-2">
          <button
            onClick={onNewChat}
            className="flex w-full items-center gap-3 rounded-full bg-surface-hover px-4 py-2.5 text-sm font-medium transition-colors hover:bg-surface-light"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            New chat
          </button>
        </div>

        <div className="flex flex-1 flex-col gap-0.5 overflow-y-auto p-2 pb-safe">
          {conversations.length === 0 && (
            <p className="p-4 text-center text-[13px] text-neutral-400">No conversations yet</p>
          )}
          {conversations.map((conv) => (
            <ConversationItem
              key={conv.id}
              conversation={conv}
              isActive={conv.id === activeId}
              onSelect={() => {
                onSelectChat(conv.id);
                // Auto-close sidebar on mobile after selecting a chat
                if (window.matchMedia("(max-width: 767px)").matches) {
                  onToggle();
                }
              }}
              onDelete={() => onDeleteChat(conv.id)}
              onRename={(title) => onRenameChat(conv.id, title)}
            />
          ))}
        </div>
      </aside>
    </>
  );
}

interface ConversationItemProps {
  conversation: Conversation;
  isActive: boolean;
  onSelect: () => void;
  onDelete: () => void;
  onRename: (title: string) => void;
}

function ConversationItem({
  conversation,
  isActive,
  onSelect,
  onDelete,
  onRename,
}: ConversationItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(conversation.title);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleSubmitRename = () => {
    if (editValue.trim()) {
      onRename(editValue);
    } else {
      setEditValue(conversation.title);
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSubmitRename();
    } else if (e.key === "Escape") {
      setEditValue(conversation.title);
      setIsEditing(false);
    }
  };

  return (
    <div
      onClick={onSelect}
      className={`group flex cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2.5 transition-colors ${
        isActive ? "bg-surface-hover" : "hover:bg-white/5"
      }`}
    >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="shrink-0 text-neutral-400">
        <path
          d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"
          stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
        />
      </svg>

      {isEditing ? (
        <input
          ref={inputRef}
          type="text"
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={handleSubmitRename}
          onClick={(e) => e.stopPropagation()}
          className="flex-1 rounded bg-bg px-1.5 py-0.5 text-[13px] text-neutral-100 outline-none ring-1 ring-brand-500"
        />
      ) : (
        <span className="flex-1 truncate text-[13px]">{conversation.title}</span>
      )}

      {!isEditing && (
        <div className="flex shrink-0 items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
          {/* Rename button (pencil icon) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setEditValue(conversation.title);
              setIsEditing(true);
            }}
            className="rounded p-1 text-neutral-400 transition-colors hover:bg-white/10 hover:text-neutral-100"
            aria-label="Rename conversation"
            title="Rename"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path
                d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
              />
              <path
                d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
              />
            </svg>
          </button>

          {/* Delete button (trash icon) */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="rounded p-1 text-neutral-400 transition-colors hover:bg-red-500/20 hover:text-red-400"
            aria-label="Delete conversation"
            title="Delete"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path
                d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14z"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>
      )}
    </div>
  );
}
