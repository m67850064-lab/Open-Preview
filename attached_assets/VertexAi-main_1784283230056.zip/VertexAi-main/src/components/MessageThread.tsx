import type { ChatMessage } from "../types";

interface MessageThreadProps {
  messages: ChatMessage[];
}

export function MessageThread({ messages }: MessageThreadProps) {
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 px-3 pb-6 sm:gap-6 sm:px-4 sm:pb-8">
      {messages.map((msg) => (
        <MessageBubble key={msg.id} message={msg} />
      ))}
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";
  const isTyping = message.role === "model" && message.text === "";

  return (
    <div className={`flex gap-3 animate-fade-in ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-500 to-brand-400">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" />
            <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="2" strokeLinejoin="round" opacity="0.7" />
          </svg>
        </div>
      )}
      <div
        className={`max-w-[75%] whitespace-pre-wrap break-words px-4 py-3 text-[15px] leading-relaxed ${
          isUser
            ? "rounded-[20px_20px_4px_20px] bg-brand-500 text-white"
            : "rounded-[20px_20px_20px_4px] bg-surface text-neutral-100"
        }`}
      >
        {isTyping ? (
          <span className="inline-flex gap-1 py-1">
            <span className="h-2 w-2 rounded-full bg-neutral-400 animate-pulse-dot" />
            <span className="h-2 w-2 rounded-full bg-neutral-400 animate-pulse-dot [animation-delay:0.2s]" />
            <span className="h-2 w-2 rounded-full bg-neutral-400 animate-pulse-dot [animation-delay:0.4s]" />
          </span>
        ) : (
          message.text
        )}
      </div>
    </div>
  );
}
