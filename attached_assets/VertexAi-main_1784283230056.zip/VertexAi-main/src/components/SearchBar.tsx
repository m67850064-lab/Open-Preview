import { useState, useRef } from "react";
import { useSpeechRecognition } from "../hooks/useSpeechRecognition";

interface SearchBarProps {
  onSend: (text: string) => void;
}

export function SearchBar({ onSend }: SearchBarProps) {
  const [input, setInput] = useState("");

  // Store the setInput function in a ref so the SpeechRecognition
  // onresult handler (created once inside the hook) can call the
  // functional form: setInput(prev => prev ? prev + " " + t : t)
  const setInputRef = useRef(setInput);
  setInputRef.current = setInput;

  const { isSupported, isListening, toggleListening } =
    useSpeechRecognition(setInputRef);

  const handleSend = () => {
    if (!input.trim()) return;
    onSend(input);
    setInput("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex justify-center px-3 pb-safe pt-2 sm:px-4 sm:pb-6">
      <div className="flex w-full max-w-3xl items-center gap-2 rounded-full border border-surface-light bg-surface py-1.5 pl-4 pr-1.5 sm:pl-5 transition-all focus-within:border-brand-500 focus-within:ring-1 focus-within:ring-brand-500">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Message Vertex AI..."
          className="flex-1 bg-transparent py-2.5 text-[15px] text-neutral-100 outline-none placeholder:text-neutral-500"
        />

        {/* Microphone button — wired to Web Speech API */}
        <button
          aria-label={isListening ? "Stop voice input" : "Voice input"}
          title={isSupported ? (isListening ? "Stop listening" : "Voice input") : "Voice input not supported"}
          onClick={toggleListening}
          disabled={!isSupported}
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-all ${
            !isSupported
              ? "cursor-not-allowed text-neutral-600"
              : isListening
                ? "bg-red-500 text-white animate-pulse"
                : "text-neutral-400 hover:bg-surface-hover hover:text-neutral-100"
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>

        {/* Send button */}
        <button
          aria-label="Send message"
          onClick={handleSend}
          disabled={!input.trim()}
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-all ${
            input.trim() ? "bg-brand-500 text-white hover:bg-brand-600" : "cursor-default bg-surface-hover text-neutral-400"
          }`}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className={input.trim() ? "translate-x-px" : ""}>
            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>
    </div>
  );
}
