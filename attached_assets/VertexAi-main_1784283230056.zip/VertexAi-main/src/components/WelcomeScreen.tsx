interface WelcomeScreenProps {
  samplePrompts: string[];
  onPromptClick: (text: string) => void;
  onNewChat: () => void;
}

export function WelcomeScreen({ samplePrompts, onPromptClick }: WelcomeScreenProps) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-6 px-4 py-6 sm:gap-10 sm:py-8 animate-fade-in-slow">
      <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-400 sm:h-16 sm:w-16">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#fff" strokeWidth="2" strokeLinejoin="round" />
          <path d="M2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="2" strokeLinejoin="round" opacity="0.7" />
        </svg>
      </div>

      <div className="text-center">
        <h1 className="mb-2 bg-gradient-to-r from-brand-400 to-brand-500 bg-clip-text font-heading text-3xl font-bold leading-tight text-transparent sm:text-4xl">
          Hello, Vertex AI
        </h1>
        <p className="text-base text-neutral-400">How can I help you today?</p>
      </div>

      <div className="mt-2 grid w-full max-w-2xl grid-cols-1 gap-3 sm:grid-cols-2">
        {samplePrompts.map((prompt, i) => (
          <button
            key={i}
            onClick={() => onPromptClick(prompt)}
            className="flex items-center gap-2.5 rounded-xl border border-surface-light bg-surface px-4 py-3.5 text-left text-sm transition-all hover:border-brand-500 hover:bg-surface-hover hover:-translate-y-0.5"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="shrink-0 text-brand-400">
              <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
            </svg>
            {prompt}
          </button>
        ))}
      </div>
    </div>
  );
}
