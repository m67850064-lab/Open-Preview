import type { Conversation } from "../types";
import { MessageThread } from "./MessageThread";
import { SearchBar } from "./SearchBar";
import { WelcomeScreen } from "./WelcomeScreen";

interface ChatAreaProps {
  conversation: Conversation | null;
  onSendMessage: (text: string) => void;
  sidebarOpen: boolean;
  onToggleSidebar: () => void;
  samplePrompts: string[];
  onNewChat: () => void;
}

export function ChatArea({
  conversation,
  onSendMessage,
  sidebarOpen,
  onToggleSidebar,
  samplePrompts,
  onNewChat,
}: ChatAreaProps) {
  const messages = conversation?.messages ?? [];
  const isEmpty = messages.length === 0;

  return (
    <main className="relative flex flex-1 flex-col overflow-hidden">
      {/* Header — hamburger always visible on mobile, only when collapsed on md+ */}
      <header className="flex h-14 items-center gap-3 pl-safe pr-safe pt-safe">
        {/* Hamburger menu button */}
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle sidebar"
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-neutral-300 transition-all hover:bg-surface-hover ${
            sidebarOpen ? "md:hidden" : ""
          }`}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path
              d="M3 12h18M3 6h18M3 18h18"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>

        <span className="font-heading text-lg font-medium text-neutral-400">Vertex AI</span>
      </header>

      <div className="flex flex-1 flex-col overflow-y-auto">
        {isEmpty ? (
          <WelcomeScreen samplePrompts={samplePrompts} onPromptClick={onSendMessage} onNewChat={onNewChat} />
        ) : (
          <MessageThread messages={messages} />
        )}
      </div>

      <SearchBar onSend={onSendMessage} />
    </main>
  );
}
