export type Role = "user" | "model";

export interface ChatMessage {
  id: string;
  role: Role;
  text: string;
  timestamp: number;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
}
