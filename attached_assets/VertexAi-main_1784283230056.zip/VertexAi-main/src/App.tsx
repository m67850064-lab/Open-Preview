import { useState, useEffect, useCallback } from "react";
import type { ChatMessage, Conversation } from "./types";
import { Sidebar } from "./components/Sidebar";
import { ChatArea } from "./components/ChatArea";
import { generateWithFailover } from "./lib/failover";

const STORAGE_KEY = "vertex-ai-conversations";

function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveConversations(convs: Conversation[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(convs));
  } catch {
    /* ignore */
  }
}

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const SAMPLE_PROMPTS = [
  "Explain quantum computing in simple terms",
  "Write a poem about the ocean",
  "Give me ideas for a weekend project",
  "What are the latest AI trends?",
];

const SYSTEM_PROMPT =
  "You are Vertex AI, a friendly and helpful conversational assistant. " +
  "Reply directly and naturally in the same language the user speaks — " +
  "whether that is English, Hindi, Roman Urdu, or any other language. " +
  "Be concise, clear, and conversational. Do not echo or repeat the user's " +
  "question back. Just answer helpfully.";

export default function App() {
  const [conversations, setConversations] = useState<Conversation[]>(loadConversations);
  const [activeId, setActiveId] = useState<string | null>(
    conversations.length > 0 ? conversations[0].id : null
  );
  // Sidebar open by default on md+ (tablet/desktop), closed on mobile
  const [sidebarOpen, setSidebarOpen] = useState(() =>
    typeof window !== "undefined" ? window.matchMedia("(min-width: 768px)").matches : true
  );

  // Auto-close sidebar when resizing down to mobile, auto-open on md+
  useEffect(() => {
    const mq = window.matchMedia("(min-width: 768px)");
    const handler = (e: MediaQueryListEvent) => setSidebarOpen(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    saveConversations(conversations);
  }, [conversations]);

  const activeConversation = conversations.find((c) => c.id === activeId) ?? null;

  const handleNewChat = useCallback(() => {
    const conv: Conversation = {
      id: uid(),
      title: "New chat",
      messages: [],
      createdAt: Date.now(),
    };
    setConversations((prev) => [conv, ...prev]);
    setActiveId(conv.id);
  }, []);

  const handleSelectChat = useCallback((id: string) => setActiveId(id), []);

  const handleDeleteChat = useCallback(
    (id: string) => {
      setConversations((prev) => {
        const filtered = prev.filter((c) => c.id !== id);
        if (activeId === id) {
          setActiveId(filtered.length > 0 ? filtered[0].id : null);
        }
        return filtered;
      });
    },
    [activeId]
  );

  const handleRenameChat = useCallback((id: string, newTitle: string) => {
    const trimmed = newTitle.trim();
    if (!trimmed) return;
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: trimmed } : c))
    );
  }, []);

  const handleSendMessage = useCallback(
    (text: string) => {
      if (!text.trim()) return;

      const userMsg: ChatMessage = {
        id: uid(),
        role: "user",
        text: text.trim(),
        timestamp: Date.now(),
      };
      const modelMsg: ChatMessage = {
        id: uid(),
        role: "model",
        text: "",
        timestamp: Date.now(),
      };

      setConversations((prev) => {
        const conv = prev.find((c) => c.id === activeId);
        let updated: Conversation[];
        if (!conv) {
          const newConv: Conversation = {
            id: uid(),
            title: text.trim().slice(0, 40),
            messages: [userMsg, modelMsg],
            createdAt: Date.now(),
          };
          updated = [newConv, ...prev];
          setActiveId(newConv.id);
        } else {
          const title =
            conv.messages.length === 0 ? text.trim().slice(0, 40) : conv.title;
          updated = prev.map((c) =>
            c.id === conv.id
              ? { ...c, title, messages: [...c.messages, userMsg, modelMsg] }
              : c
          );
        }
        return updated;
      });

      // Pass the raw user input directly to the failover chain — no
      // template wrapper, no hardcoded fallback text. The system prompt
      // instructs the model to respond naturally in the user's language.
      const targetId = modelMsg.id;
      generateWithFailover({ prompt: text.trim(), systemPrompt: SYSTEM_PROMPT })
        .then((result) => {
          setConversations((prev) =>
            prev.map((c) => ({
              ...c,
              messages: c.messages.map((m) =>
                m.id === targetId ? { ...m, text: result.text } : m
              ),
            }))
          );
        })
        .catch((err) => {
          const errMsg =
            "Sorry, I couldn't reach any of the AI providers. Please try again in a moment.";
          console.error("Failover error:", err);
          setConversations((prev) =>
            prev.map((c) => ({
              ...c,
              messages: c.messages.map((m) =>
                m.id === targetId ? { ...m, text: errMsg } : m
              ),
            }))
          );
        });
    },
    [activeId]
  );

  const toggleSidebar = useCallback(() => setSidebarOpen((s) => !s), []);

  return (
    <div className="flex h-full w-full">
      <Sidebar
        conversations={conversations}
        activeId={activeId}
        isOpen={sidebarOpen}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
        onRenameChat={handleRenameChat}
        onToggle={toggleSidebar}
      />
      <ChatArea
        conversation={activeConversation}
        onSendMessage={handleSendMessage}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={toggleSidebar}
        samplePrompts={SAMPLE_PROMPTS}
        onNewChat={handleNewChat}
      />
    </div>
  );
}
