import { useState, useRef, useCallback, useEffect } from "react";

type SetInputFn = (
  updater: string | ((prev: string) => string)
) => void;

/**
 * Wraps the browser Web Speech API (SpeechRecognition) for voice-to-text.
 *
 * Uses continuous=true and interimResults=false so the microphone stays
 * active and keeps listening until the user manually clicks to stop.
 *
 * The caller passes a React setInput function (via a ref) so that
 * recognition.onresult can update the input state using the functional
 * form: setInput(prev => prev ? prev + " " + transcript : transcript).
 * This guarantees the live text-box value is always read and appended to,
 * never overwritten — even across multiple mic activations.
 */
export function useSpeechRecognition(setInputRef: React.MutableRefObject<SetInputFn>) {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const shouldListenRef = useRef(false);

  const isSupported =
    typeof window !== "undefined" &&
    (typeof window.SpeechRecognition !== "undefined" ||
      typeof window.webkitSpeechRecognition !== "undefined");

  useEffect(() => {
    if (!isSupported) return;

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    const recognition = new SR();
    recognition.lang = "en-US";
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalText += result[0].transcript;
        }
      }
      const transcript = finalText.trim();
      if (!transcript) return;

      // Functional state update — reads the current live input value and
      // appends the new speech cleanly at the end. Never overwrites.
      const setInput = setInputRef.current;
      setInput((prev: string) => (prev ? prev + " " + transcript : transcript));
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.warn("Speech recognition error:", event.error);
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        shouldListenRef.current = false;
        setIsListening(false);
      }
    };

    recognition.onend = () => {
      // In continuous mode the browser may still fire onend after a pause.
      // If the user hasn't manually stopped, restart recognition so it
      // keeps listening continuously.
      if (shouldListenRef.current) {
        try {
          recognition.start();
        } catch {
          // start() throws if already started — ignore
        }
      } else {
        setIsListening(false);
      }
    };

    recognitionRef.current = recognition;

    return () => {
      shouldListenRef.current = false;
      recognition.abort();
      recognitionRef.current = null;
    };
  }, [isSupported, setInputRef]);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) return;

    if (isListening) {
      shouldListenRef.current = false;
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      shouldListenRef.current = true;
      try {
        recognitionRef.current.start();
      } catch {
        // start() throws if already started — ignore
      }
    }
  }, [isListening]);

  return {
    isSupported,
    isListening,
    toggleListening,
  };
}
