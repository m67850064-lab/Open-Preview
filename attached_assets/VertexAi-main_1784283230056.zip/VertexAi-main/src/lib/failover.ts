/**
 * Dynamic API Failover / Backup System for text generation.
 *
 * Chain order (primary -> final resort):
 *   1. Gemini API      (Google Generative Language)
 *   2. Groq Cloud API  (OpenAI-compatible)
 *   3. Mistral API    (OpenAI-compatible)
 *   4. OpenRouter API  (OpenAI-compatible, multi-model gateway)
 *
 * If a provider returns a rate-limit error (429), a network failure, or
 * any non-200 status, the error is caught automatically and the prompt
 * is retried with the next provider in the chain — transparently to the
 * caller and the UI.
 */

const env = import.meta.env;

export interface GenerateOptions {
  prompt: string;
  systemPrompt?: string;
  signal?: AbortSignal;
}

export interface GenerateResult {
  text: string;
  provider: string;
}

/** A single provider adapter — knows how to call one API and parse its text. */
interface Provider {
  name: string;
  generate(opts: GenerateOptions): Promise<string>;
}

const GEMINI_MODEL = "gemini-1.5-flash-latest";
const GROQ_MODEL = "llama-3.3-70b-versatile";
const MISTRAL_MODEL = "mistral-small-latest";
const OPENROUTER_MODEL = "openai/gpt-4o-mini";

const gemini: Provider = {
  name: "Gemini",
  async generate({ prompt, systemPrompt, signal }) {
    const key = env.VITE_GEMINI_API_KEY;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${key}`;

    const contents = [];
    if (systemPrompt) {
      contents.push({ role: "user", parts: [{ text: systemPrompt }] });
      contents.push({ role: "model", parts: [{ text: "Understood." }] });
    }
    contents.push({ role: "user", parts: [{ text: prompt }] });

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents, generationConfig: { temperature: 0.7, maxOutputTokens: 1024 } }),
      signal,
    });

    if (!res.ok) throw new ApiError(`Gemini HTTP ${res.status}`, res.status);
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) throw new ApiError("Gemini: empty response", res.status);
    return text;
  },
};

const groq: Provider = {
  name: "Groq",
  async generate({ prompt, systemPrompt, signal }) {
    const key = env.VITE_GROQ_API_KEY;
    const url = "https://api.groq.com/openai/v1/chat/completions";

    const messages = [];
    if (systemPrompt) messages.push({ role: "system", content: systemPrompt });
    messages.push({ role: "user", content: prompt });

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({ model: GROQ_MODEL, messages, temperature: 0.7, max_tokens: 1024 }),
      signal,
    });

    if (!res.ok) throw new ApiError(`Groq HTTP ${res.status}`, res.status);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new ApiError("Groq: empty response", res.status);
    return text;
  },
};

const mistral: Provider = {
  name: "Mistral",
  async generate({ prompt, systemPrompt, signal }) {
    const key = env.VITE_MISTRAL_API_KEY;
    const url = "https://api.mistral.ai/v1/chat/completions";

    const messages = [];
    if (systemPrompt) messages.push({ role: "system", content: systemPrompt });
    messages.push({ role: "user", content: prompt });

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({ model: MISTRAL_MODEL, messages, temperature: 0.7, max_tokens: 1024 }),
      signal,
    });

    if (!res.ok) throw new ApiError(`Mistral HTTP ${res.status}`, res.status);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new ApiError("Mistral: empty response", res.status);
    return text;
  },
};

const openrouter: Provider = {
  name: "OpenRouter",
  async generate({ prompt, systemPrompt, signal }) {
    const key = env.VITE_OPENROUTER_API_KEY;
    const url = "https://openrouter.ai/api/v1/chat/completions";

    const messages = [];
    if (systemPrompt) messages.push({ role: "system", content: systemPrompt });
    messages.push({ role: "user", content: prompt });

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
        "HTTP-Referer": "https://vertex-ai-chat.app",
        "X-Title": "Vertex AI Chat",
      },
      body: JSON.stringify({ model: OPENROUTER_MODEL, messages, temperature: 0.7, max_tokens: 1024 }),
      signal,
    });

    if (!res.ok) throw new ApiError(`OpenRouter HTTP ${res.status}`, res.status);
    const data = await res.json();
    const text = data?.choices?.[0]?.message?.content;
    if (!text) throw new ApiError("OpenRouter: empty response", res.status);
    return text;
  },
};

/** Ordered fallback chain: primary -> first backup -> second backup -> final resort. */
const CHAIN: Provider[] = [gemini, groq, mistral, openrouter];

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

/**
 * Generate text using the dynamic fallback chain.
 *
 * Tries each provider in order. If a provider throws (network failure,
 * rate-limit 429, or any non-200 status), the error is caught and the
 * next provider is tried automatically. Returns the first successful
 * response along with the provider name that produced it.
 *
 * Throws only if every provider in the chain fails.
 */
export async function generateWithFailover(
  opts: GenerateOptions
): Promise<GenerateResult> {
  const errors: string[] = [];

  for (const provider of CHAIN) {
    try {
      const text = await provider.generate(opts);
      return { text, provider: provider.name };
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : String(err);
      errors.push(`${provider.name}: ${msg}`);
      // Continue to next provider in the chain
    }
  }

  throw new Error(
    `All providers failed:\n${errors.join("\n")}`
  );
}
