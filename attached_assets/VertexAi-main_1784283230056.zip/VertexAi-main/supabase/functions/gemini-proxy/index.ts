import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SYSTEM_PROMPT =
  "Your name is Gemini. Always strictly maintain the language chosen by the user in the conversation (if they talk in Urdu/Roman Urdu, reply fully in that language) and never mention Groq or Llama.";

function sanitizeInput(input: string): string {
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "")
    .replace(/javascript:/gi, "")
    .replace(/on\w+\s*=/gi, "")
    .replace(/data:/gi, "")
    .trim();
}

interface ChatMessage {
  role: string;
  content: string;
}

interface AttachedFile {
  data: string;
  mimeType: string;
}

interface ApiKeysPayload {
  gemini?: string;
  groq?: string;
  together?: string;
  mistral?: string;
  openrouter?: string;
}

interface RequestBody {
  prompt?: string;
  files?: AttachedFile[];
  history?: ChatMessage[];
  apiKeys?: ApiKeysPayload;
}

interface ProviderResult {
  ok: boolean;
  status: number;
  body: string;
  data?: any;
}

interface Provider {
  name: string;
  envKey: string;
  model: string;
  call: (apiKey: string, body: RequestBody, sanitizedPrompt: string) => Promise<ProviderResult>;
  extractText: (data: any) => string | undefined;
}

// ---------------------------------------------------------------------------
// Provider chain — exact order: Gemini, Groq, Together, Mistral, OpenRouter
// ---------------------------------------------------------------------------

const PROVIDER_CHAIN: Provider[] = [
  {
    name: "gemini",
    envKey: "GEMINI_API_KEY",
    model: "gemini-1.5-flash",
    call: callGeminiAdapter,
    extractText: (data) => data?.candidates?.[0]?.content?.parts?.[0]?.text,
  },
  {
    name: "groq",
    envKey: "GROQ_API_KEY",
    model: "llama3-8b-8192",
    call: (key, body, prompt) =>
      callOpenAICompatible(
        "https://api.groq.com/openai/v1/chat/completions",
        key,
        "llama3-8b-8192",
        body,
        prompt
      ),
    extractText: (data) => data?.choices?.[0]?.message?.content,
  },
  {
    name: "together",
    envKey: "TOGETHER_API_KEY",
    model: "meta-llama/Llama-3-8b-chat-hf",
    call: (key, body, prompt) =>
      callOpenAICompatible(
        "https://api.together.xyz/v1/chat/completions",
        key,
        "meta-llama/Llama-3-8b-chat-hf",
        body,
        prompt
      ),
    extractText: (data) => data?.choices?.[0]?.message?.content,
  },
  {
    name: "mistral",
    envKey: "MISTRAL_API_KEY",
    model: "mistral-small-latest",
    call: (key, body, prompt) =>
      callOpenAICompatible(
        "https://api.mistral.ai/v1/chat/completions",
        key,
        "mistral-small-latest",
        body,
        prompt
      ),
    extractText: (data) => data?.choices?.[0]?.message?.content,
  },
  {
    name: "openrouter",
    envKey: "OPENROUTER_API_KEY",
    model: "meta-llama/llama-3-8b-instruct:free",
    call: (key, body, prompt) =>
      callOpenAICompatible(
        "https://openrouter.ai/api/v1/chat/completions",
        key,
        "meta-llama/llama-3-8b-instruct:free",
        body,
        prompt
      ),
    extractText: (data) => data?.choices?.[0]?.message?.content,
  },
];

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function isRateLimitOrQuota(status: number, errorBody: string): boolean {
  if (status === 429) return true;
  if (status === 403 || status === 503) {
    const lower = errorBody.toLowerCase();
    return (
      lower.includes("resource_exhausted") ||
      lower.includes("quota") ||
      lower.includes("rate limit") ||
      lower.includes("rate_limit")
    );
  }
  return false;
}

function buildGeminiContents(body: RequestBody) {
  const contents: Array<{
    role: string;
    parts: Array<{ text?: string; inlineData?: { data: string; mimeType: string } }>;
  }> = [];

  // System instruction is passed separately via systemInstruction field
  if (body.history && Array.isArray(body.history)) {
    body.history.forEach((msg) => {
      contents.push({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: sanitizeInput(msg.content) }],
      });
    });
  }

  const currentParts: Array<{ text?: string; inlineData?: { data: string; mimeType: string } }> = [];
  const sanitizedPrompt = body.prompt ? sanitizeInput(body.prompt) : "";

  if (sanitizedPrompt) {
    currentParts.push({ text: sanitizedPrompt });
  }

  if (body.files && Array.isArray(body.files) && body.files.length > 0) {
    body.files.forEach((file) => {
      currentParts.push({
        inlineData: { data: file.data, mimeType: file.mimeType },
      });
    });
  }

  contents.push({ role: "user", parts: currentParts });
  return { contents, sanitizedPrompt };
}

function buildChatMessages(body: RequestBody, sanitizedPrompt: string) {
  const messages: Array<{ role: string; content: string }> = [];

  // System prompt first — applies to all OpenAI-compatible providers
  messages.push({ role: "system", content: SYSTEM_PROMPT });

  if (body.history && Array.isArray(body.history)) {
    body.history.forEach((msg) => {
      messages.push({
        role: msg.role === "user" ? "user" : "assistant",
        content: sanitizeInput(msg.content),
      });
    });
  }

  let userContent = sanitizedPrompt;
  if (body.files && body.files.length > 0) {
    const fileNote = body.files
      .map((f, i) => `[attachment ${i + 1}: ${f.mimeType}]`)
      .join(" ");
    userContent = userContent ? `${userContent}\n\n${fileNote}` : fileNote;
  }

  if (userContent) {
    messages.push({ role: "user", content: userContent });
  }

  return messages;
}

// ---------------------------------------------------------------------------
// Provider call implementations
// ---------------------------------------------------------------------------

async function callGemini(
  apiKey: string,
  body: RequestBody,
  _sanitizedPrompt: string
): Promise<ProviderResult> {
  const { contents } = buildGeminiContents(body);
  const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

  const response = await fetch(geminiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
    }),
  });

  const text = await response.text();
  if (!response.ok) return { ok: false, status: response.status, body: text };

  return { ok: true, status: response.status, body: text, data: JSON.parse(text) };
}

function callGeminiAdapter(
  apiKey: string,
  body: RequestBody,
  sanitizedPrompt: string
): Promise<ProviderResult> {
  return callGemini(apiKey, body, sanitizedPrompt);
}

async function callOpenAICompatible(
  url: string,
  apiKey: string,
  model: string,
  body: RequestBody,
  sanitizedPrompt: string
): Promise<ProviderResult> {
  const messages = buildChatMessages(body, sanitizedPrompt);

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ model, messages, temperature: 0.7 }),
  });

  const text = await response.text();
  if (!response.ok) return { ok: false, status: response.status, body: text };

  return { ok: true, status: response.status, body: text, data: JSON.parse(text) };
}

// ---------------------------------------------------------------------------
// Response helper
// ---------------------------------------------------------------------------

function jsonResponse(payload: unknown, status: number): Response {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ---------------------------------------------------------------------------
// Main handler — iterates the provider chain
// ---------------------------------------------------------------------------

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return jsonResponse({ error: "Method not allowed" }, 405);
  }

  try {
    const body: RequestBody = await req.json();
    const { prompt, files } = body;

    console.log(
      "Request received - prompt length:",
      prompt?.length || 0,
      "files:",
      files?.length || 0
    );

    if (!prompt && (!files || files.length === 0)) {
      return jsonResponse({ error: "No prompt or files provided" }, 400);
    }

    const sanitizedPrompt = prompt ? sanitizeInput(prompt) : "";

    // Resolve keys: request body takes precedence, then Deno env vars as fallback
    const bodyKeys = body.apiKeys || {};
    const keyMap: Record<string, string> = {
      GEMINI_API_KEY: bodyKeys.gemini || Deno.env.get("GEMINI_API_KEY") || "",
      GROQ_API_KEY: bodyKeys.groq || Deno.env.get("GROQ_API_KEY") || "",
      TOGETHER_API_KEY: bodyKeys.together || Deno.env.get("TOGETHER_API_KEY") || "",
      MISTRAL_API_KEY: bodyKeys.mistral || Deno.env.get("MISTRAL_API_KEY") || "",
      OPENROUTER_API_KEY: bodyKeys.openrouter || Deno.env.get("OPENROUTER_API_KEY") || "",
    };

    const availableProviders = PROVIDER_CHAIN.filter(
      (p) => !!keyMap[p.envKey]
    );

    const configuredNames = PROVIDER_CHAIN.map(
      (p) => `${p.name}:${keyMap[p.envKey] ? "yes" : "no"}`
    ).join(" | ");
    console.log("Provider availability:", configuredNames);

    if (availableProviders.length === 0) {
      return jsonResponse(
        {
          error:
            "No API keys configured. Set at least one of: GEMINI_API_KEY, GROQ_API_KEY, TOGETHER_API_KEY, MISTRAL_API_KEY, OPENROUTER_API_KEY.",
          code: "NO_API_KEY",
        },
        503
      );
    }

    const failureLog: Array<{
      provider: string;
      status: number;
      reason: string;
      rateLimited: boolean;
    }> = [];

    // Try each provider in chain order
    for (const provider of availableProviders) {
      const apiKey = keyMap[provider.envKey];
      console.log(`Trying provider: ${provider.name} (${provider.model})...`);

      try {
        const result = await provider.call(apiKey, body, sanitizedPrompt);

        if (result.ok) {
          const text = provider.extractText(result.data);
          if (text) {
            console.log(`Provider ${provider.name} succeeded`);
            return jsonResponse({
              success: true,
              response: text,
              provider: provider.name,
            });
          }
          console.error(
            `${provider.name} returned no text:`,
            JSON.stringify(result.data).substring(0, 500)
          );
          failureLog.push({
            provider: provider.name,
            status: result.status,
            reason: "No text in response",
            rateLimited: false,
          });
        } else {
          const rateLimited = isRateLimitOrQuota(result.status, result.body);
          console.error(
            `${provider.name} failed (${result.status})${rateLimited ? " [rate-limited/quota]" : ""}:`,
            result.body.substring(0, 500)
          );
          failureLog.push({
            provider: provider.name,
            status: result.status,
            reason: result.body.substring(0, 200),
            rateLimited,
          });
        }
      } catch (err) {
        console.error(`${provider.name} threw an error:`, err);
        failureLog.push({
          provider: provider.name,
          status: 0,
          reason: err instanceof Error ? err.message : "Unknown error",
          rateLimited: false,
        });
      }

      console.log(`Falling back from ${provider.name} to next provider...`);
    }

    // All providers exhausted
    console.error("All providers failed:", JSON.stringify(failureLog));
    return jsonResponse(
      {
        error: "All AI providers failed to respond.",
        failures: failureLog,
      },
      502
    );
  } catch (error) {
    console.error("Edge function error:", error);
    return jsonResponse(
      {
        error: "Internal server error",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      500
    );
  }
});
