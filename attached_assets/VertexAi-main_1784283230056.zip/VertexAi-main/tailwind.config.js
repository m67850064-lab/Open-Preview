/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        heading: ['"Google Sans"', "Roboto", "sans-serif"],
        body: ["Roboto", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#e8f0fe",
          100: "#d2e3fc",
          200: "#aecbfa",
          300: "#8ab4f8",
          400: "#669df6",
          500: "#1a73e8",
          600: "#1557b0",
          700: "#174ea6",
          800: "#174ea6",
          900: "#0d47a1",
        },
        surface: {
          DEFAULT: "#28292c",
          hover: "#35363a",
          light: "#3c4043",
        },
        bg: {
          DEFAULT: "#1e1f20",
          light: "#2d2e31",
        },
      },
      animation: {
        "fade-in": "fadeIn 300ms ease",
        "fade-in-slow": "fadeIn 400ms ease",
        "pulse-dot": "pulseDot 1s ease-in-out infinite",
      },
      keyframes: {
        fadeIn: {
          from: { opacity: "0", transform: "translateY(8px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        pulseDot: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.4" },
        },
      },
    },
  },
  plugins: [],
};
